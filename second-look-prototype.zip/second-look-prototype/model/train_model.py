"""
Second Look: train the explainable risk model on SYNTHETIC data.

What this script does
1. Simulates payments that were picked up by the cheap rules layer
   (new payee, changed bank account, unusual amount, recent edit).
   Most are genuine. About 6% are scams (fake "new bank details").
2. Turns each payment into 9 simple signals (features), each scaled 0 to 1.
3. Trains a logistic regression. We use this model on purpose:
   every signal gets one weight, so the app can show the checker
   exactly WHY a payment was flagged (explainable AI, MAS FEAT).
4. Compares the model with a rules-only approach ("alert on every change").
5. Writes the weights and test results to:
     model/weights.json        (for reading / grading)
     js/model-weights.js       (loaded by index.html, works offline)

All data here is made up. Replace simulate() with real, consented,
anonymised DBS data in a real pilot.

Run:  python model/train_model.py
Needs: numpy, scikit-learn
"""

import json
import os
from datetime import date

import numpy as np
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import precision_score, recall_score, roc_auc_score
from sklearn.model_selection import train_test_split

SEED = 7
N_EVENTS = 20000
SCAM_RATE = 0.06

# Thresholds used by the app. Kept here so the model card and the app agree.
AMBER_FROM = 0.30
RED_FROM = 0.70

# Order matters: js/engine.js builds features in the same order.
FEATURES = [
    ("new_account",      "Account first seen in DBS network less than 30 days ago"),
    ("low_network_trust", "Few or no other DBS clients pay this account under the same name"),
    ("mule_flag",        "Account is on DBS's scam (mule) watchlist"),
    ("country_mismatch", "Account country differs from the supplier's country"),
    ("name_mismatch",    "Account holder name does not match the supplier name"),
    ("amount_spike",     "Amount is far above the usual payment to this supplier"),
    ("rushed_edit",      "Payee details were edited less than 1 hour before the payment"),
    ("new_device",       "Payment created from a device not seen before"),
    ("no_po_match",      "No matching purchase order or invoice on record"),
]

# Signals we deliberately do NOT use (fairness). Shown on the model card.
EXCLUDED = [
    "Supplier or person names' language, origin or ethnicity",
    "Hyphens, spacing or spelling style in names",
    "Nationality of directors or staff",
    "Company size or how much the client banks with DBS",
]


def network_trust(payers):
    """1 = nobody else pays this account, 0 = 50+ other DBS clients do."""
    return 1.0 - min(np.log1p(payers) / np.log1p(50), 1.0)


def amount_spike(ratio):
    """0 = normal amount, 1 = 8x or more than the usual payment."""
    return float(min(np.log2(max(ratio, 1.0)) / 3.0, 1.0))


def simulate(n, scam_rate, rng):
    """Return raw signals and labels (1 = scam) for n rule-triggered payments."""
    is_scam = rng.random(n) < scam_rate
    rows = []
    # The two groups deliberately overlap so the problem is realistic:
    # many scams copy a normal invoice amount and use look-alike names,
    # and some genuine suppliers really do open brand-new accounts.
    for scam in is_scam:
        if scam:
            r = rng.random()
            if r < 0.70:
                payers = 0
            elif r < 0.90:
                payers = int(rng.integers(1, 6))
            else:
                payers = int(rng.lognormal(1.5, 1.0))  # compromised older account
            first_seen_days = int(rng.integers(1, 30)) if rng.random() < 0.65 else int(rng.integers(30, 600))
            mule = rng.random() < 0.20
            country_mismatch = rng.random() < 0.50
            name_match = float(rng.uniform(0.40, 0.95))
            ratio = float(rng.uniform(1.0, 5.0)) if rng.random() < 0.6 else float(rng.uniform(0.7, 1.5))
            rushed = rng.random() < 0.50
            new_device = rng.random() < 0.30
            no_po = rng.random() < 0.45
        else:
            payers = int(rng.lognormal(2.0, 1.3)) if rng.random() < 0.75 else int(rng.integers(0, 4))
            first_seen_days = int(rng.integers(1, 30)) if rng.random() < 0.20 else int(rng.integers(30, 3000))
            mule = rng.random() < 0.003
            country_mismatch = rng.random() < 0.08
            name_match = float(rng.uniform(0.75, 1.0)) if rng.random() < 0.85 else float(rng.uniform(0.45, 0.75))
            ratio = float(rng.uniform(0.6, 1.6)) if rng.random() < 0.75 else float(rng.uniform(1.6, 4.0))
            rushed = rng.random() < 0.15
            new_device = rng.random() < 0.08
            no_po = rng.random() < 0.25
        rows.append([
            1.0 if first_seen_days < 30 else 0.0,
            network_trust(payers),
            1.0 if mule else 0.0,
            1.0 if country_mismatch else 0.0,
            round(1.0 - name_match, 3),
            amount_spike(ratio),
            1.0 if rushed else 0.0,
            1.0 if new_device else 0.0,
            1.0 if no_po else 0.0,
        ])
    return np.array(rows), is_scam.astype(int)


def main():
    rng = np.random.default_rng(SEED)
    X, y = simulate(N_EVENTS, SCAM_RATE, rng)
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.3, random_state=SEED, stratify=y
    )

    model = LogisticRegression(max_iter=1000, class_weight="balanced")
    model.fit(X_train, y_train)

    proba = model.predict_proba(X_test)[:, 1]
    flagged = proba >= AMBER_FROM            # amber or red = checker is asked to verify
    held = proba >= RED_FROM                 # red = payment held for DBS call-back

    n_test = int(len(y_test))
    n_scams = int(y_test.sum())
    n_genuine = n_test - n_scams

    # Rules-only baseline: every rule-triggered payment raises an alert.
    rules = {
        "alerts": n_test,
        "scams_caught": n_scams,
        "false_alarms": n_genuine,
        "alerts_per_scam": round(n_test / max(n_scams, 1), 1),
    }
    second_look = {
        "alerts": int(flagged.sum()),
        "held": int(held.sum()),
        "scams_caught": int((flagged & (y_test == 1)).sum()),
        "scams_held": int((held & (y_test == 1)).sum()),
        "false_alarms": int((flagged & (y_test == 0)).sum()),
        "alerts_per_scam": round(int(flagged.sum()) / max(int((flagged & (y_test == 1)).sum()), 1), 1),
        "recall": round(recall_score(y_test, flagged), 3),
        "precision": round(precision_score(y_test, flagged), 3),
        "auc": round(roc_auc_score(y_test, proba), 3),
    }

    out = {
        "model": "Logistic regression (explainable)",
        "trained_on": "SYNTHETIC data only, for prototype demonstration",
        "trained_date": date.today().isoformat(),
        "n_events": N_EVENTS,
        "scam_rate": SCAM_RATE,
        "intercept": round(float(model.intercept_[0]), 4),
        "features": [
            {"key": k, "label": label, "weight": round(float(w), 4)}
            for (k, label), w in zip(FEATURES, model.coef_[0])
        ],
        "thresholds": {"amber_from": AMBER_FROM, "red_from": RED_FROM},
        "excluded_signals": EXCLUDED,
        "evaluation": {
            "test_events": n_test,
            "test_scams": n_scams,
            "rules_only": rules,
            "second_look": second_look,
        },
    }

    here = os.path.dirname(os.path.abspath(__file__))
    root = os.path.dirname(here)
    with open(os.path.join(here, "weights.json"), "w") as f:
        json.dump(out, f, indent=2)
    with open(os.path.join(root, "js", "model-weights.js"), "w") as f:
        f.write("// Generated by model/train_model.py. Do not edit by hand.\n")
        f.write("window.SECOND_LOOK_MODEL = ")
        json.dump(out, f, indent=2)
        f.write(";\n")

    print("Weights:")
    for feat in out["features"]:
        print(f"  {feat['key']:<18} {feat['weight']:+.3f}")
    print(f"  intercept          {out['intercept']:+.3f}")
    print("\nTest set:", n_test, "rule-triggered payments,", n_scams, "scams")
    print("Rules only  :", rules)
    print("Second Look :", second_look)


if __name__ == "__main__":
    main()
