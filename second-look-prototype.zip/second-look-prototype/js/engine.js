// Second Look engine: rules layer + explainable AI risk model + evidence card text.
//
// Layer 1 (rules, cheap, no AI cost): only payments with a trigger go to the AI.
// Layer 2 (AI model): scores the payment using weights trained in model/train_model.py.
// Layer 3 (explanation): turns the strongest signals into plain-English observations.
//   In production an LLM would write this card, grounded ONLY on these structured
//   signals, so it cannot invent facts. Here we use templates so the demo runs offline.

(function () {
  const MODEL = window.SECOND_LOOK_MODEL;
  const LN51 = Math.log(51);

  const fmt = (n) => "S$" + Math.round(n).toLocaleString("en-SG");

  function amountRatio(p) {
    if (!p.avgAmount12m) return 1;
    return p.amount / p.avgAmount12m;
  }

  // ---------- Layer 1: rules ----------
  function ruleTriggers(p) {
    const t = [];
    if (p.accountChanged) t.push("Bank account changed");
    if (p.newPayee) t.push("New payee");
    if (amountRatio(p) >= 2) t.push("Amount 2x or more above usual");
    if (p.editedMinutesBefore !== null && p.editedMinutesBefore < 1440) t.push("Payee edited in last 24 hours");
    if (p.muleFlag) t.push("Account on scam watchlist");
    return t;
  }

  // ---------- Layer 2: features (same order and maths as train_model.py) ----------
  function features(p) {
    const ratio = Math.max(amountRatio(p), 1);
    return {
      new_account: p.accountFirstSeenDays < 30 ? 1 : 0,
      low_network_trust: 1 - Math.min(Math.log(1 + p.networkPayers) / LN51, 1),
      mule_flag: p.muleFlag ? 1 : 0,
      country_mismatch: p.accountCountry !== p.supplierCountry ? 1 : 0,
      name_mismatch: +(1 - p.nameMatch).toFixed(3),
      amount_spike: Math.min(Math.log2(ratio) / 3, 1),
      rushed_edit: p.editedMinutesBefore !== null && p.editedMinutesBefore < 60 ? 1 : 0,
      new_device: p.newDevice ? 1 : 0,
      no_po_match: p.poMatch ? 0 : 1,
    };
  }

  function score(p) {
    const x = features(p);
    let z = MODEL.intercept;
    const contributions = MODEL.features.map((f) => {
      const c = f.weight * x[f.key];
      z += c;
      return { key: f.key, label: f.label, value: x[f.key], weight: f.weight, contribution: c };
    });
    const prob = 1 / (1 + Math.exp(-z));
    // Shown as 0 to 99: the model is never 100% certain.
    return { score: Math.min(99, Math.round(prob * 100)), contributions };
  }

  function levelFor(score100) {
    const t = MODEL.thresholds;
    if (score100 >= t.red_from * 100) return "red";
    if (score100 >= t.amber_from * 100) return "amber";
    return "green";
  }

  // ---------- Layer 3: observations in plain English ----------
  function observations(p) {
    const out = [];
    const ratio = amountRatio(p);
    const add = (type, text, key) => out.push({ type, text, key });

    if (p.accountChanged) {
      add("info", `Bank account changed from ${p.oldAccount} to ${p.newAccount}.`, "change");
    }
    if (p.newPayee) add("info", "First payment to this payee.", "change");

    if (p.muleFlag) add("concern", "This account is on DBS's scam (mule) watchlist.", "mule_flag");

    if (p.networkPayers === 0) {
      add("concern", "No other DBS client has ever paid this account.", "low_network_trust");
    } else if (p.networkPayers < 5) {
      add("concern", `Only ${p.networkPayers} other DBS client${p.networkPayers > 1 ? "s" : ""} pay this account, so there is little history to rely on.`, "low_network_trust");
    } else if (p.accountChanged || p.newPayee) {
      add("ok", `${p.networkPayers} other DBS clients already pay this account under the same supplier name.`, "low_network_trust");
    }

    if (p.accountFirstSeenDays < 30) {
      add("concern", `Account first appeared in DBS's network ${p.accountFirstSeenDays} days ago.`, "new_account");
    } else if (p.accountChanged || p.newPayee) {
      add("ok", `Account has been active in DBS's network for ${p.accountFirstSeenDays} days.`, "new_account");
    }

    if (p.accountCountry !== p.supplierCountry) {
      add("concern", `Account is in ${p.accountCountry}, but the supplier is based in ${p.supplierCountry}.`, "country_mismatch");
    } else if (p.accountChanged || p.newPayee) {
      add("ok", `Account is in the same country as the supplier (${p.supplierCountry}).`, "country_mismatch");
    }

    const pct = Math.round(p.nameMatch * 100);
    if (p.nameMatch < 0.85) {
      add("concern", `Account holder name "${p.accountHolderName}" only partly matches "${p.payee}" (${pct}% match).`, "name_mismatch");
    } else if (p.accountChanged || p.newPayee) {
      add("ok", `Account holder name matches the supplier (${pct}% match).`, "name_mismatch");
    }

    if (p.avgAmount12m && ratio >= 1.5) {
      add("concern", `Amount ${fmt(p.amount)} is ${ratio.toFixed(1)}x your usual ${fmt(p.avgAmount12m)} to this supplier.`, "amount_spike");
    } else if (p.avgAmount12m) {
      add("ok", `Amount is in line with your usual payments to this supplier (${fmt(p.avgAmount12m)} average).`, "amount_spike");
    }

    if (p.editedMinutesBefore !== null && p.editedMinutesBefore < 60) {
      add("concern", `Payee details were edited ${p.editedMinutesBefore} minutes before this payment was created.`, "rushed_edit");
    }
    if (p.newDevice) add("concern", "Payment was created from a device not seen before.", "new_device");

    if (p.poMatch) add("ok", `Invoice matches a purchase order on record (${p.invoiceRef}).`, "no_po_match");
    else add("concern", `No matching purchase order found for ${p.invoiceRef}.`, "no_po_match");

    return out;
  }

  function summary(level, p) {
    if (level === "red") {
      return `This looks like a fake bank-detail change. Payment is held until DBS verifies with ${p.payee} on your saved contact.`;
    }
    if (level === "amber") {
      return "The change could be genuine, but there is not enough history to be sure. Call the supplier on the number in your own records before approving.";
    }
    if (p.accountChanged) {
      return "The account change looks genuine. Signals match a normal supplier bank switch.";
    }
    if (p.newPayee) return "New payee looks genuine. Account is established and matches the supplier.";
    return "Account is unchanged and trusted. Amount is higher than usual, so check the order quantity, but no scam signals were found.";
  }

  function assess(p, aiEnabled) {
    const triggers = ruleTriggers(p);
    if (triggers.length === 0) {
      return { routine: true, level: "green", triggers, aiUsed: false, score: null, tokens: 0 };
    }
    if (!aiEnabled) {
      // Kill switch on: fall back to today's rules-only behaviour.
      return { routine: false, level: "rules", triggers, aiUsed: false, score: null, tokens: 0 };
    }
    const s = score(p);
    const level = levelFor(s.score);
    return {
      routine: false,
      level,
      triggers,
      aiUsed: true,
      score: s.score,
      contributions: s.contributions,
      observations: observations(p),
      summary: summary(level, p),
      tokens: window.SL_DATA.costAssumptions.tokensPerCard,
    };
  }

  window.SecondLook = { assess, ruleTriggers, features, score, levelFor, fmt };
})();
