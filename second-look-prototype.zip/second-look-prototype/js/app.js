// Second Look prototype UI. Plain JavaScript, no build step, works on GitHub Pages
// or by double-clicking index.html.

(function () {
  const D = window.SL_DATA;
  const M = window.SECOND_LOOK_MODEL;
  const SL = window.SecondLook;
  const fmt = SL.fmt;

  const state = {
    aiEnabled: true,
    intent: "supplier",
    selectedId: null,
    status: {},     // id -> { kind, text, tone }
    verified: {},   // id -> true once the checker ticks the call-back checklist
    holds: {},      // id -> { remaining (seconds), step }
    tradeUsed: D.tradeLine.used,
    audit: [],
  };

  const LEVEL_TEXT = { green: "Green", amber: "Amber", red: "Red", rules: "Rules alert", routine: "Routine" };
  const ORDER = { red: 0, amber: 1, rules: 2, green: 3, routine: 4 };
  const COOLING_OFF_SECONDS = 12 * 60 * 60;
  const DEMO_SPEED = 600; // demo clock runs 600x faster

  const INTENTS = {
    supplier: {
      label: "Supplier payments", tag: "pilot", live: true,
      checks: "changed or new bank accounts, amount vs history and purchase orders, rushed edits, unfamiliar devices",
      outcome: "stops fake bank-detail scams without blocking genuine supplier bank switches",
    },
    payroll: {
      label: "Payroll", tag: "phase 2", live: false,
      checks: "new or changed employee accounts, two salaries into one account, staff missing from recent payroll, unusual amounts",
      outcome: "catches salary-diversion scams and ghost employees",
    },
    fx: {
      label: "Overseas and FX", tag: "phase 3", live: false,
      checks: "payment currency vs invoice currency, amount vs the underlying invoice, supplier country vs account country",
      outcome: "catches wrong-currency and extra-zero mistakes on large overseas payments",
    },
  };

  const $ = (sel) => document.querySelector(sel);
  const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const clock = () => new Date().toLocaleTimeString("en-SG", { hour: "2-digit", minute: "2-digit", second: "2-digit", hour12: false });
  const levelOf = (a) => (a.routine ? "routine" : a.level);
  const pillClass = (level) => (level === "routine" ? "grey" : level);
  const byId = (id) => D.payments.find((p) => p.id === id);
  const tradeAvailable = () => D.tradeLine.limit - state.tradeUsed;

  function assessAll() {
    return D.payments.map((p) => {
      const a = SL.assess(p, state.aiEnabled);
      // Red payments are held automatically. Money never leaves until DBS verifies.
      if (a.level === "red" && !state.status[p.id] && !state.holds[p.id]) startHold(p, a, "Auto-held by Second Look (red)");
      return { p, a };
    });
  }

  function log(p, a, action, user) {
    state.audit.unshift({
      time: clock(),
      user: user || "Mr Tan",
      id: p ? p.id : "",
      payee: p ? p.payee : "All payments",
      ai: !a ? "" : a.aiUsed ? `${LEVEL_TEXT[a.level]} (${a.score}/100)` : a.routine ? "Routine, no AI" : "Rules alert, AI paused",
      action,
    });
  }

  function startHold(p, a, reason) {
    state.holds[p.id] = { remaining: COOLING_OFF_SECONDS, step: 3 };
    log(p, a, reason + ". 12-hour cooling-off started.", "Second Look");
  }

  function hms(sec) {
    const s = Math.max(0, Math.round(sec));
    const h = String(Math.floor(s / 3600)).padStart(2, "0");
    const m = String(Math.floor((s % 3600) / 60)).padStart(2, "0");
    const r = String(s % 60).padStart(2, "0");
    return `${h}:${m}:${r}`;
  }

  // ---------- Header, intent, summary ----------
  function renderWho() {
    $("#who").innerHTML = `Signed in as <strong>${esc(D.checker)}</strong><br>${esc(D.company)} · ${esc(D.segment)}`;
  }

  function renderIntent() {
    const chips = Object.entries(INTENTS).map(([key, it]) =>
      `<button class="chip ${state.intent === key ? "active" : ""}" data-intent="${key}">${esc(it.label)}<small>${esc(it.tag)}</small></button>`
    ).join("");
    $("#intent").innerHTML = `<span class="label">What are you approving?</span>${chips}`;
    const it = INTENTS[state.intent];
    $("#intentNote").innerHTML = it.live
      ? `<b>Workflow for ${esc(it.label.toLowerCase())}:</b> Second Look checks ${esc(it.checks)}. <b>Outcome:</b> ${esc(it.outcome)}.`
      : `<b>${esc(it.tag[0].toUpperCase() + it.tag.slice(1))} preview, not live in this prototype.</b> For ${esc(it.label.toLowerCase())}, Second Look will check ${esc(it.checks)}. <b>Outcome:</b> ${esc(it.outcome)}. The pilot starts with supplier payments only.`;
    const live = it.live;
    $("#summary").hidden = !live;
    document.querySelector(".layout").hidden = !live;
  }

  function renderSummary(list) {
    const waiting = list.filter((x) => !state.status[x.p.id]).length;
    const count = (lv) => list.filter((x) => levelOf(x.a) === lv).length;
    const aiRuns = list.filter((x) => x.a.aiUsed).length;
    const tokens = list.reduce((t, x) => t + x.a.tokens, 0);
    const ruleAlerts = list.filter((x) => !x.a.routine).length;
    const parts = [
      `<div class="stat"><b>${waiting}</b>waiting for you</div>`,
      state.aiEnabled
        ? `<div class="stat"><b>${count("red")}</b>red · <b>${count("amber")}</b>amber · <b>${count("green") + count("routine")}</b>green</div>`
        : `<div class="stat"><b>${count("rules")}</b>rules alerts to check by hand</div>`,
      `<div class="stat">AI ran on <b>${aiRuns}</b>of ${list.length} payments (${tokens.toLocaleString()} tokens)</div>`,
      `<div class="stat">Rules alone would alert on <b>${ruleAlerts}</b></div>`,
    ];
    $("#summary").innerHTML = parts.join("");
  }

  // ---------- Queue ----------
  function renderQueue(list) {
    const sorted = [...list].sort((x, y) => ORDER[levelOf(x.a)] - ORDER[levelOf(y.a)]);
    const items = sorted.map(({ p, a }) => {
      const lv = levelOf(a);
      const st = state.status[p.id];
      const tags = [];
      if (p.accountChanged) tags.push('<span class="tag">Account changed</span>');
      if (p.newPayee) tags.push('<span class="tag">New payee</span>');
      if (state.holds[p.id] && !st) tags.push('<span class="tag">Held</span>');
      const right = st ? `<span class="done">${esc(st.kind)}</span>` : `<span class="pill ${pillClass(lv)}">${LEVEL_TEXT[lv]}</span>`;
      return `<button class="q-item ${state.selectedId === p.id ? "selected" : ""}" data-id="${p.id}" aria-pressed="${state.selectedId === p.id}">
          <span class="q-payee">${esc(p.payee)}</span>
          <span class="q-amount">${fmt(p.amount)}</span>
          <span class="q-meta">${esc(p.id)} · ${esc(p.createdBy)}, ${esc(p.createdAt)}</span>
          <span class="q-tags">${tags.join("")}${right}</span>
        </button>`;
    }).join("");
    $("#queue").innerHTML = `<h2>Waiting for your approval</h2>${items}`;
  }

  // ---------- Evidence card ----------
  function verdictHtml(p, a) {
    if (a.routine) {
      return `<div class="verdict grey">Routine payment: same account, normal amount. No AI check needed, 0 tokens used.</div>`;
    }
    if (!a.aiUsed) {
      return `<div class="verdict rules">Rules alert: ${esc(a.triggers.join(", "))}. AI is paused, so verify this payment with the supplier yourself before approving.</div>`;
    }
    return `<div class="verdict ${a.level}">
        <div>${LEVEL_TEXT[a.level]} · Risk score ${a.score}/100</div>
        <div class="meter" aria-hidden="true"><span style="width:${Math.max(a.score, 2)}%"></span></div>
        <div class="meter-label">${esc(a.summary)}</div>
      </div>`;
  }

  function observationsHtml(a) {
    if (!a.aiUsed) return "";
    const icon = { concern: "!", ok: "✓", info: "•" };
    const items = a.observations.map((o) => `<li class="${o.type}"><span class="ic" aria-hidden="true">${icon[o.type]}</span><span>${esc(o.text)}</span></li>`).join("");
    return `<div><div class="section-title">What Second Look saw</div><ul class="obs">${items}</ul></div>`;
  }

  function whyHtml(a) {
    if (!a.aiUsed) return "";
    const rows = [...a.contributions].sort((x, y) => y.contribution - x.contribution);
    // Fixed scale (the largest weight in the model), so small pushes look small.
    const max = Math.max(...M.features.map((f) => f.weight));
    const html = rows.map((r) => `<div class="contrib">
        <span>${esc(r.label)}</span>
        <span class="bar"><span style="width:${Math.round((r.contribution / max) * 100)}%"></span></span>
        <span class="num">+${r.contribution.toFixed(1)}</span>
      </div>`).join("");
    return `<details class="why"><summary>Why this rating (AI reasoning)</summary>${html}
      <p class="why-note">Each bar shows how much a signal pushed the risk score up. Weights come from model/train_model.py. Names' language or origin are never used.</p>
    </details>`;
  }

  function factsHtml(p, a) {
    const rows = [
      ["Pay to", p.newAccount || p.oldAccount],
      p.accountChanged ? ["Previous account", p.oldAccount] : null,
      ["Invoice", p.invoiceRef],
      ["Prepared by", `${p.createdBy}, ${p.createdAt}`],
      ["Saved supplier contact", p.savedContact],
      p.note ? ["Maker's note", p.note] : null,
      a.triggers.length ? ["Rules that fired", a.triggers.join(", ")] : null,
    ].filter(Boolean);
    return `<div><div class="section-title">Payment details</div><dl class="facts">${rows.map(([k, v]) => `<dt>${esc(k)}</dt><dd>${esc(v)}</dd>`).join("")}</dl></div>`;
  }

  function holdHtml(p, a) {
    const h = state.holds[p.id];
    const steps = [
      ["Flagged by Second Look" + (a.aiUsed ? ` (risk score ${a.score}/100)` : ""), "done"],
      ["Payment held and 12-hour cooling-off started. Money has not left your account.", "done"],
      [`DBS fraud team calls you on your registered number, and the supplier on its saved number: ${p.savedContact}.`, "now"],
      ["Decision: release the payment, or cancel it and report the account.", ""],
    ];
    return `<div class="hold">
        <h4>Payment held for DBS verification</h4>
        <div class="timer" id="timer">${hms(h.remaining)}<small>Cooling-off time left (demo clock runs ${DEMO_SPEED}x faster)</small></div>
        <ol class="steps">${steps.map(([t, c]) => `<li class="${c}"><span class="dot"></span><span>${esc(t)}</span></li>`).join("")}</ol>
        <div class="actions">
          <button class="btn danger" data-act="cb-fake">Demo: supplier says the account is FAKE</button>
          <button class="btn" data-act="cb-genuine">Demo: supplier confirms change is genuine</button>
        </div>
        <p class="note">Approve stays locked until DBS completes the call-back. Safety comes before speed.</p>
      </div>`;
  }

  function actionsHtml(p, a) {
    const lv = levelOf(a);
    if (state.holds[p.id]) {
      return `<div class="actions"><button class="btn danger" data-act="reject">Cancel payment now</button></div>`;
    }
    const needsCheck = lv === "amber" || lv === "rules";
    let html = "";
    if (needsCheck) {
      html += `<div class="box">
          <h4>Before you approve</h4>
          <div>Call ${esc(p.payee)} on the number in <b>your own records</b>: ${esc(p.savedContact)}. Do not use contact details from the invoice or email.</div>
          <label class="check"><input type="checkbox" data-act="verify" ${state.verified[p.id] ? "checked" : ""}>
            <span>I called the supplier on our saved number and they confirmed the new account ${esc((p.newAccount || "").split(" ").pop())}.</span></label>
        </div>`;
    }
    const canTrade = a.aiUsed && a.level === "green";
    if (canTrade) {
      const avail = tradeAvailable();
      const ok = p.poMatch && p.amount <= avail;
      html += `<div class="box trade">
          <h4>Pay now, repay DBS later</h4>
          <div>Invoice verified, so you can pay the supplier today with a <b>DBS Trade Loan</b> of up to ${D.tradeLine.maxTenorDays} days, within your approved line (${fmt(avail)} available). Pricing: ${esc(D.tradeLine.pricing)}.</div>
          ${ok ? "" : `<div class="note">${p.poMatch ? "Amount exceeds available line." : "Upload a matching purchase order to use the trade loan."}</div>`}
          <div class="actions"><button class="btn" data-act="approve-trade" ${ok ? "" : "disabled"}>Approve and pay with Trade Loan</button></div>
        </div>`;
    }
    const approveDisabled = needsCheck && !state.verified[p.id];
    html += `<div class="actions">
        <button class="btn primary" data-act="approve" ${approveDisabled ? "disabled" : ""}>Approve</button>
        ${lv === "amber" ? `<button class="btn" data-act="hold">Hold and ask DBS to verify</button>` : ""}
        <button class="btn danger" data-act="reject">Reject</button>
      </div>`;
    return html;
  }

  function renderDetail(list) {
    const el = $("#detail");
    const item = list.find((x) => x.p.id === state.selectedId);
    if (!item) {
      el.innerHTML = `<h2>Evidence card</h2><div class="empty">Select a payment to see Second Look's evidence card.</div>`;
      return;
    }
    const { p, a } = item;
    const st = state.status[p.id];
    let body = `<div class="ev-head">
        <div><h3>${esc(p.payee)}</h3><div class="sub">${esc(p.id)} · ${esc(p.supplierCountry)} supplier · ${p.paymentsToPayee} past payments</div></div>
        <div class="ev-amount">${fmt(p.amount)}</div>
      </div>`;
    body += verdictHtml(p, a);
    if (st) {
      body += `<div class="result-msg ${st.tone}">${esc(st.text)}</div>`;
      if (a.aiUsed) body += `<div class="feedback">Your decision was sent back as feedback for the next model retraining.</div>`;
    } else if (state.holds[p.id]) {
      body += holdHtml(p, a);
    }
    body += observationsHtml(a);
    body += whyHtml(a);
    body += factsHtml(p, a);
    if (!st) body += actionsHtml(p, a);
    el.innerHTML = `<h2>Evidence card</h2><div class="detail-body">${body}</div>`;
  }

  // ---------- Actions ----------
  function act(kind) {
    const p = byId(state.selectedId);
    if (!p) return;
    const a = SL.assess(p, state.aiEnabled);
    const acct = p.newAccount || p.oldAccount;
    switch (kind) {
      case "verify":
        state.verified[p.id] = !state.verified[p.id];
        if (state.verified[p.id]) log(p, a, "Checker confirmed new account with supplier on saved number");
        break;
      case "approve":
        state.status[p.id] = { kind: "Approved", tone: "green", text: `Approved. ${fmt(p.amount)} released to ${acct}.` };
        log(p, a, "Approved");
        break;
      case "approve-trade":
        state.tradeUsed += p.amount;
        state.status[p.id] = { kind: "Approved", tone: "green", text: `Approved and paid with a DBS Trade Loan. Supplier is paid today, repay DBS within ${D.tradeLine.maxTenorDays} days. Trade line still available: ${fmt(tradeAvailable())}.` };
        log(p, a, `Approved, paid with DBS Trade Loan (${fmt(p.amount)})`);
        break;
      case "reject":
        delete state.holds[p.id];
        state.status[p.id] = { kind: "Rejected", tone: "grey", text: "Rejected. The payment was returned to the maker with your comment. No money left your account." };
        log(p, a, "Rejected by checker");
        break;
      case "hold":
        startHold(p, a, "Checker asked DBS to verify");
        break;
      case "cb-fake":
        delete state.holds[p.id];
        state.status[p.id] = { kind: "Cancelled", tone: "red", text: `Scam stopped. The supplier confirmed it never changed its bank account, so the payment was cancelled and ${fmt(p.amount)} never left your account. DBS has reported the account. If you shared any other details, call the ScamShield Helpline on 1799.` };
        log(p, a, "DBS call-back: supplier denied the change. Payment cancelled, account reported", "DBS fraud team");
        break;
      case "cb-genuine":
        delete state.holds[p.id];
        state.status[p.id] = { kind: "Released", tone: "green", text: `Released after DBS confirmed the change with the supplier. ${fmt(p.amount)} sent to ${acct}.` };
        log(p, a, "DBS call-back: supplier confirmed the change. Payment released", "DBS fraud team");
        break;
    }
    render();
  }

  // ---------- Pilot results ----------
  function cmpRow(title, rulesVal, aiVal, max) {
    const w = (v) => Math.max(Math.round((v / max) * 100), v > 0 ? 1 : 0);
    return `<div class="cmp-row"><div class="t">${esc(title)}</div>
        <div class="cmp-bar"><span>Rules only</span><span class="track"><span class="fill rules" style="width:${w(rulesVal)}%;display:block"></span></span><span class="v">${rulesVal.toLocaleString()}</span></div>
        <div class="cmp-bar"><span>Second Look</span><span class="track"><span class="fill ai" style="width:${w(aiVal)}%;display:block"></span></span><span class="v">${aiVal.toLocaleString()}</span></div>
      </div>`;
  }

  function renderResults() {
    const ev = M.evaluation;
    const r = ev.rules_only;
    const s = ev.second_look;
    const fewer = Math.round((1 - s.alerts / r.alerts) * 100);
    const missed = ev.test_scams - s.scams_caught;
    const c = D.costAssumptions;
    const tokens = c.ruleTriggered * c.tokensPerCard;
    const aiCost = (tokens / 1000) * c.costPer1kTokensSGD;

    $("#results").innerHTML = `<div class="grid-2">
      <div class="card pad">
        <h2>Second Look vs alerting on every change</h2>
        <p class="lead">Test on ${ev.test_events.toLocaleString()} synthetic payments that tripped a rule, of which ${ev.test_scams} were scams.</p>
        <div class="kpis">
          <div class="kpi"><b>${fewer}%</b><span>fewer alerts for checkers</span></div>
          <div class="kpi"><b>${Math.round(s.recall * 100)}%</b><span>of scams still caught</span></div>
          <div class="kpi"><b>${r.alerts_per_scam} → ${s.alerts_per_scam}</b><span>alerts per real scam</span></div>
        </div>
        <div class="cmp">
          ${cmpRow("Alerts the checker must handle", r.alerts, s.alerts, r.alerts)}
          ${cmpRow("False alarms", r.false_alarms, s.false_alarms, r.alerts)}
          ${cmpRow("Scams caught", r.scams_caught, s.scams_caught, ev.test_scams)}
          ${cmpRow("Scams held for DBS call-back", 0, s.scams_held, ev.test_scams)}
        </div>
        <p class="note">Honest limit: Second Look missed ${missed} of ${ev.test_scams} scams in this test. DBS's existing fraud monitoring, payment limits and cooling periods still apply, so Second Look adds a layer instead of replacing one. Model AUC ${s.auc}.</p>
      </div>
      <div class="card pad">
        <h2>Who pays for the AI (tokens)</h2>
        <p class="lead">One SME client, one month. All figures are assumptions.</p>
        <div class="table-wrap"><table>
          <tr><td>Payments approved</td><td class="num">${c.paymentsThisMonth}</td></tr>
          <tr><td>Tripped a rule, so AI ran</td><td class="num">${c.ruleTriggered} (${Math.round((c.ruleTriggered / c.paymentsThisMonth) * 100)}%)</td></tr>
          <tr><td>Tokens used (${c.tokensPerCard.toLocaleString()} per evidence card)</td><td class="num">${tokens.toLocaleString()}</td></tr>
          <tr><td>AI cost to DBS (S$${c.costPer1kTokensSGD} per 1,000 tokens)</td><td class="num">S$${aiCost.toFixed(2)}</td></tr>
          <tr><td>Second Look add-on fee paid by client</td><td class="num">S$${c.monthlyPlanSGD.toFixed(2)}</td></tr>
          <tr><td><b>DBS margin on the add-on</b></td><td class="num"><b>S$${(c.monthlyPlanSGD - aiCost).toFixed(2)}</b></td></tr>
        </table></div>
        <p class="note">Cheap rules run on every payment. The AI only runs after a rule trips, so the client's fee covers the token cost. Loan, FX and transfer pricing are unchanged.</p>
        <h2>Value to each side</h2>
        <ul class="plain">
          <li><b>Client:</b> avoids business email compromise losses (about S$219k per case in H1 2026), and approves faster because most payments are green.</li>
          <li><b>DBS:</b> add-on fee, trade loan interest on verified invoices, and fewer scam cases to investigate.</li>
        </ul>
      </div>
    </div>`;
  }

  // ---------- Governance ----------
  function renderGovernance() {
    const feats = [...M.features].sort((x, y) => y.weight - x.weight);
    const audit = state.audit.length
      ? `<div class="table-wrap"><table><tr><th>Time</th><th>Who</th><th>Payment</th><th>AI result</th><th>Action</th></tr>${state.audit.map((e) =>
          `<tr><td>${esc(e.time)}</td><td>${esc(e.user)}</td><td>${esc(e.id)} ${esc(e.payee)}</td><td>${esc(e.ai)}</td><td>${esc(e.action)}</td></tr>`).join("")}</table></div>`
      : `<p class="note">No decisions yet. Approve, reject or hold a payment to see it logged here.</p>`;

    $("#governance").innerHTML = `<div class="grid-2">
      <div class="card pad">
        <h2>Kill switch</h2>
        <label class="switch"><input type="checkbox" id="aiToggle" ${state.aiEnabled ? "checked" : ""}> AI checks ${state.aiEnabled ? "on" : "off"}</label>
        <p class="note">Turning AI off falls back instantly to today's rules-only alerts. DBS can use this if the model misbehaves, and the review board can pause it at any time.</p>
        <h2>Safety nets</h2>
        <ul class="plain">
          <li><b>Humans decide.</b> The AI only advises. The checker approves green and amber payments.</li>
          <li><b>Red means held.</b> 12-hour cooling-off plus a DBS call-back before any money moves.</li>
          <li><b>Shadow pilot first.</b> 3 months where the AI scores silently, to measure accuracy before anyone sees it.</li>
          <li><b>Grounded explanations.</b> Every card is built only from the signals listed, so the AI cannot invent facts.</li>
          <li><b>Privacy.</b> Other DBS clients are never named, only counted (PDPA and banking secrecy).</li>
          <li><b>Fairness.</b> Name language, origin and spelling style are never used, and false alarm rates are reviewed monthly (MAS FEAT principles).</li>
          <li><b>Feedback loop.</b> Checker and DBS call-back outcomes retrain the model each quarter.</li>
        </ul>
      </div>
      <div class="card pad">
        <h2>Model card</h2>
        <dl class="facts">
          <dt>Model</dt><dd>${esc(M.model)}</dd>
          <dt>Training data</dt><dd>${esc(M.trained_on)} (${M.n_events.toLocaleString()} events, ${Math.round(M.scam_rate * 100)}% scams)</dd>
          <dt>Trained</dt><dd>${esc(M.trained_date)}</dd>
          <dt>Ratings</dt><dd>Green below ${M.thresholds.amber_from * 100}, amber ${M.thresholds.amber_from * 100} to ${M.thresholds.red_from * 100 - 1}, red ${M.thresholds.red_from * 100} and above</dd>
        </dl>
        <div class="table-wrap"><table>
          <tr><th>Signal used</th><th class="num">Weight</th></tr>
          ${feats.map((f) => `<tr><td>${esc(f.label)}</td><td class="num">${f.weight.toFixed(2)}</td></tr>`).join("")}
        </table></div>
        <div><div class="section-title">Never used</div><ul class="plain">${M.excluded_signals.map((x) => `<li>${esc(x)}</li>`).join("")}</ul></div>
      </div>
    </div>
    <div class="card pad" style="margin-top:16px">
      <h2>Audit trail</h2>
      ${audit}
    </div>`;
  }

  // ---------- Main render + events ----------
  function render() {
    const list = assessAll();
    $("#killBanner").hidden = state.aiEnabled;
    renderWho();
    renderIntent();
    renderSummary(list);
    renderQueue(list);
    renderDetail(list);
    if (!$("#tab-results").hidden) renderResults();
    if (!$("#tab-governance").hidden) renderGovernance();
  }

  document.addEventListener("click", (e) => {
    const tab = e.target.closest("[data-tab]");
    if (tab) {
      document.querySelectorAll("[data-tab]").forEach((b) => b.setAttribute("aria-selected", String(b === tab)));
      document.querySelectorAll(".panel").forEach((s) => (s.hidden = s.id !== "tab-" + tab.dataset.tab));
      render();
      return;
    }
    const chip = e.target.closest("[data-intent]");
    if (chip) { state.intent = chip.dataset.intent; render(); return; }
    const item = e.target.closest(".q-item");
    if (item) {
      state.selectedId = item.dataset.id;
      render();
      if (window.innerWidth <= 860) $("#detail").scrollIntoView({ behavior: "smooth", block: "start" });
      return;
    }
    const btn = e.target.closest("button[data-act]");
    if (btn && !btn.disabled) act(btn.dataset.act);
  });

  document.addEventListener("change", (e) => {
    if (e.target.matches('input[data-act="verify"]')) act("verify");
    if (e.target.id === "aiToggle") {
      state.aiEnabled = e.target.checked;
      log(null, null, state.aiEnabled ? "Kill switch off, AI checks resumed" : "Kill switch on, rules-only fallback", "DBS model owner");
      render();
    }
  });

  // Demo clock for cooling-off holds.
  setInterval(() => {
    let changed = false;
    for (const id in state.holds) {
      const h = state.holds[id];
      if (h.remaining > 0) { h.remaining -= DEMO_SPEED / 4; changed = true; }
    }
    if (changed && state.holds[state.selectedId]) {
      const t = document.getElementById("timer");
      if (t) t.firstChild.nodeValue = hms(state.holds[state.selectedId].remaining);
    }
  }, 250);

  // Start with the riskiest payment open, so the demo begins on the red card.
  const first = assessAll().sort((x, y) => ORDER[levelOf(x.a)] - ORDER[levelOf(y.a)])[0];
  state.selectedId = first ? first.p.id : null;
  render();
})();
